package MainPck;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import geocode.GeoName;
import geocode.ReverseGeoCode;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class MainGeo {
	public static void main(String[] args) throws IOException, ParseException{
		FileInputStream fstream = null;
		fstream =new FileInputStream("C:\\Users\\sharon24\\Desktop\\OfflineReverseGeocode-master\\allCountries.txt");

		ReverseGeoCode reverseGeoCode = new ReverseGeoCode(fstream, true);
		FileReader fr;
		FileWriter outputFile = null;

		BufferedReader textreader = null;
		try {
			fr=new FileReader("C:/Users/sharon24/Documents/GitHub/InfoVisProject/data/newsItems_Events.json");

			textreader= new BufferedReader(fr);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String aLine;
		int i=0;
		int j=0;
		JSONParser parser = new JSONParser();
		//JSONArray jsonarray = (JSONArray) parser.parse(new FileReader("C:/Users/sharon24/Documents/GitHub/InfoVisProject/data/newsItemsparts/part1.json"));


		while ( ( aLine = textreader.readLine( ) ) != null ) {

			//System.out.println(aLine);
			JSONObject newsItem=(JSONObject) parser.parse(aLine);
			JSONObject point = null ;
			GeoName g1 = null;
			Object temp = newsItem.get("georss:point");
			if (temp !=null) {
				if (temp instanceof JSONArray) {
					// It's an array
					point= (JSONObject) ((JSONArray)temp).get(0);
				} 
				else if (temp instanceof JSONObject) {
					// It's an object
					point= (JSONObject)temp;
				}

				String location[];
				location=point.get("content").toString().split(" ");

				//System.out.println(location[0]  + "  " + location[1]);
				g1 =reverseGeoCode.nearestPlace(Double.parseDouble(location[0]),Double.parseDouble(location[1]));
			//	System.out.println("Nearest to " +location[0] + "  "  +location[1] + "is " + g1.country+"  " +g1.state);





			//	System.out.println(g1.country);
				if (g1.country.contains("US")) {
					if (i==0) {
						j++;
						outputFile=new FileWriter("C:/Users/sharon24/Documents/GitHub/InfoVisProject/data/newsItemsparts/part"+j+".json");

						aLine="["+aLine;

					}
					if (i>1998) {
						aLine=aLine.substring(0, aLine.length()-1);
						aLine=aLine+",\"contry\":\""+ ""+g1.country + "\",\"stateCode\":\""+ g1.state +"\"";
						aLine=aLine+"}]";
						i=0;
					} else {
						aLine=aLine.substring(0, aLine.length()-1);
						aLine=aLine+",\"contry\":\""+ ""+g1.country + "\",\"stateCode\":\""+ g1.state +"\"";
						aLine=aLine+"},";

						i++;
					}

					outputFile.write(aLine+"\n");
				
				if (i==0) {
					//	System.out.println(aLine);
					outputFile.close();	
				}
				}


			}

		}


		//	"content":"
		//georss:point":[{"content":"38.9051 -77.0162","xmlns:georss":"http://www.georss.org/georss"}
		//{"content":"38.9051 -77.0162","xmlns:georss":"http://www.georss.org/georss"}
		//	JSONParser parser = new JSONParser();
		//	 JSONArray jsonarray = (JSONArray) parser.parse(new FileReader("C:/Users/sharon24/Documents/GitHub/InfoVisProject/data/newsItemsparts/part1.json"));
		//	 JSONArray geoPoints;
		//	 int q=0;
		//	  for (Object o : jsonarray)
		//{

			//		  System.out.println(q);
			//		  JSONObject newsItem = (JSONObject) o;
			//		  JSONObject point = null ;

			//		  Object temp = newsItem.get("georss:point");
			//		  if (temp !=null) {
			//		  if (temp instanceof JSONArray) {
			// It's an array
			//			  point= (JSONObject) ((JSONArray)temp).get(0);
			//		  } 
			//		  else if (temp instanceof JSONObject) {
			//		      // It's an object
			//			  point= (JSONObject)temp;
			//		  }
			//		  
			//		//  geoPoints = (JSONArray) newsItem.get("georss:point");
			//		 // point= (JSONObject)  geoPoints.get(0);
			//		//  System.out.println(point);
			//		  String location[];
			//		  location=point.get("content").toString().split(" ");
			//		  
			//		  System.out.println(location[0]  + "  " + location[1]);
			//			GeoName g1 =reverseGeoCode.nearestPlace(Double.parseDouble(location[0]),Double.parseDouble(location[1]));
			//			System.out.println("Nearest to " +location[0] + "  "  +location[1] + "is " + g1.country+"  " +g1.state);
			//		  }
			//		  q++;
			//	  }
			//    //Object obj = parser.parse(new FileReader("C:/Users/sharon24/Documents/GitHub/InfoVisProject/data/newsItemsparts/part1"));

			//  //  JSONArray jsonarray  = new  JSONArray ();



			//	System.out.println(aLine.substring(aLine.indexOf("georss:point\":[{\"content\":")+"georss:point\":[{\"content\":".length()+1,aLine.indexOf("\",\"",  aLine.indexOf("georss:point\":[{\"content\":"))));
			//	String cor[]= aLine.substring(aLine.indexOf("georss:point\":[{\"content\":")+"georss:point\":[{\"content\":".length()+1,aLine.indexOf("\",\"xmlns:georss",  aLine.indexOf("georss:point\":[{\"content\":"))).split(" ");
			//	System.out.println(cor[0] + cor[1]);
			// jsonarray.get(index)
			//System.out.println(jsonObject.getJSONObject(0).getString("sd"));
			//	GeoName g1 =reverseGeoCode.nearestPlace(Double.parseDouble(cor[0]),Double.parseDouble(cor[1]));
			//	System.out.println("Nearest to " +cor[0] + "  "  +cor[1] + "is " + g1.country+"  " +g1.state);




			//	https://maps.googleapis.com/maps/api/geocode/json?latlng=40.714224,-73.961452&key=YOUR_API_KEY
			//  https://maps.googleapis.com/maps/api/geocode/json?latlng=37.379979%20,-122.036934&key=%20AIzaSyD37-DACdL3zXNOexg05z06ZYYNY6whcRk	
			// AIzaSyD37-DACdL3zXNOexg05z06ZYYNY6whcRk 	 

//		}

	}
}